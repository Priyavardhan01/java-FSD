var Product = /** @class */ (function () {
    function Product(code, name) {
        this.prdid = 1;
        this.prdname = "Book";
        this.qty = 0;
        this.price = 200;
        this.prdid = code;
        this.prdname = name;
    }
    Product.prototype.display = function () {
        var num = 23;
        console.log("empcode=" + this.prdid);
        console.log("prdname=" + this.prdname);
        console.log("num=" + num);
        console.log("department=" + this.qty);
        console.log("department=" + this.qty * this.price);
    };
    return Product;
}());
var emp = new Product(1, 'Anish');
emp.display();
