var msg = "Hello All!!!!!  Manisha".toUpperCase();
var heading = document.createElement('h1');
heading.textContent = msg;
document.body.appendChild(heading);
