let n1=12;
let n2 =13;
let choice =2;
switch(choice){
    case 1 :
      let  n3:any= n1+n2;
      console.log("the sum is =" +n3)
    break
    case 2 :
       let n4= n1-n2;
       console.log("the sum is =" +n4)

        break
    }
   