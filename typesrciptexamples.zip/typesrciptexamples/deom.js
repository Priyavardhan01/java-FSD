var n1 = 12;
var n2 = 13;
var choice = 2;
switch (choice) {
    case 1:
        var n3 = n1 + n2;
        console.log("the sum is =" + n3);
        break;
    case 2:
        var n4 = n1 - n2;
        console.log("the sum is =" + n4);
        break;
}
