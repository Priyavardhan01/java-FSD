let msg:string ="Hello All!!!!!  Manisha".toUpperCase();
let heading=document.createElement('h1');
heading.textContent=msg;
document.body.appendChild(heading);