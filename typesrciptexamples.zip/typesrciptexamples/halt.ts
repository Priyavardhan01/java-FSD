class Product{
    private prdid : number=1;
    private prdname :string ="Book";
    private qty :number =0;
    private price :number =200;
    
 
    constructor(prdid:number, qty:number) {
            this.prdid=prdid;
            this.qty=qty;

                   
    }
   display(){
 
    console.log("empcode="+this.prdid);
    console.log("prdname="+this.prdname);
    console.log("department="+this.qty);
    console.log("department="+this.qty*this.price);
   } 
}

let emp=new Product(1,1);
emp.display();