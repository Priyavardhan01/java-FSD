package productid;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class getdetails
 */
@WebServlet("/getdetails")
public class getdetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public getdetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	    // int id = Integer.parseInt(request.getParameter("txtid"));
	    String id  = request.getParameter("txtid"); 
		PrintWriter out = response.getWriter();
	     try {
	    	 Connection con = DBconnection.getConnection();
	    	 PreparedStatement ps = con.prepareStatement("select * from product where id=?");
				ps.setString(1, id);
				ResultSet res = ps.executeQuery();
				if(res.next())
				{
					out.println(" Product ID  : "+res.getInt(1)+"\n Product Name : "+res.getString(2) +" \nPrice :"+res.getInt(3));
				}
				else
				{
					out.println("<br> The product you searching for is not found  !!");
					out.println("<a href='index.html'> Enter Id  Again</a>");
					
					
				}
			} catch (Exception e) {
				
				e.printStackTrace();
				
			}
	     	
	}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
