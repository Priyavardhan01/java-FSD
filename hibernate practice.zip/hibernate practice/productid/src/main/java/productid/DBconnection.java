package productid;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBconnection {
    static Connection con = null;
    public static Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/ecommerce";
            String user = "root";
            String password = "650177passmysql";
            con = DriverManager.getConnection(url, user, password);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return con;
    }
}
