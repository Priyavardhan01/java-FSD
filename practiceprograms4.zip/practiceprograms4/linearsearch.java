package practiceprograms4;
import java.util.Scanner;

public class linearsearch {
	public static int linear(int arr[], int x) {
	    for (int i = 0; i < arr.length - 1; i++) {
	        if (arr[i] == x) {
	            return i;
	         }
	     }
	            return -1;
	   }

    public static void main(String[] args){

        int[] arr = {34,56,5443,3,423,2};

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the element to be searched");
        int searchValue = sc.nextInt();
            int result = (int) linear(arr,searchValue);

            if(result==-1){

                System.out.println("Element not in the array");
            } else {

                System.out.println("Element found at "+result+" and the search key is "+arr[result]);
            }

        }
}


